#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug  5 02:14:11 2023

@author: rubensanchez_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        #USER = 'aacuser1'
        #PASS = 'password'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31862
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print ("Connection Succesful")

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            # data should be dictionary     
            self.database.animals.insert_one(data)
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

# Create method to implement the R in CRUD.
    def read_all(self, data):
        cursor = self.database.animals.find(data,{"_id" :False}) #returns a cursor that directs to documents.
        return cursor
    
    def read(self,data):
        return self.database.animals.find(data)  #returns document as dictionary

# Create method to implement the U in CRUD.
    def update(self,data,UpdateData):
        if data is not None:
            result = self.database.animals.update_many(data,{"$set" : UpdateData})
        else:
            return"{}"
            print("Data Updated")
            return result.raw_result

# Create method to implement the D in CRUD.
    def delete(self, deleteData):
        if deleteData is not None:
            result = self.database.animals.delete_many(deleteData)
        else:
            return "{}"
        print ("Data Deleted")
        return result.raw_result
            
